library(rsconnect)

rsconnect::setAccountInfo(name = 'javierherraezalbarran',
                          token = '5BF992906B9E6CE437488AAF3E203CC1',
                          secret = 'mBmGb7/KIB818NLbQjECB3RA0qVLNhvfQGgPjODf')

deployApp()
